# Recursion Tree Visualizer

An interactive, high-fidelity web application built with **React**, **TypeScript**, and **Tailwind CSS** designed to visualize recursive algorithms step-by-step. It helps developers and students understand recursive depth, branching, execution logs, and call stacks in real time.

---

## 🚀 Key Features

*   **Interactive Visualizations**: Watch tree structures form dynamically as recursion branches split and return values.
*   **Step-by-Step Control**: Step forward, backward, or auto-run animations at adjustable speeds.
*   **Call Stack & Log Panels**: Highly detailed trackings of active call frames and past outcomes.
*   **Multiple Classical Algorithms**: Included presets such as Fibonacci, Factorial, Tower of Hanoi, Binary Search, Merge Sort, Quick Sort, and Pathfinding.
*   **Multi-language Support**: View corresponding code blocks in Pseudo-code, C++, Java, Python, JavaScript, or TypeScript with line-level highlighting.

---

## 💻 Running Locally (VS Code)

Follow these simple steps to run this project directly in your local development environment:

### Prerequisites

Ensure you have [Node.js](https://nodejs.org/) installed (v18 or higher is recommended).

### Setup & Run

1.  **Extract / Clean Directory**: Open the folder containing these files in VS Code.
2.  **Install Dependencies**: Run the following command in your terminal to install the clean, AI-free package definitions:
    ```bash
    npm install
    ```
3.  **Launch Dev Server**: Start the local Vite development server:
    ```bash
    npm run dev
    ```
4.  **Open in Browser**: Ctrl+Click or navigate to the local URL shown in your terminal (typically `http://localhost:3000` or `http://localhost:5173`).

---

## 📦 Building for Production

To create a highly optimized, production-ready static bundle of the visualizer:

```bash
npm run build
```

The compiled assets will be built inside the `./dist` folder, which is fully ready to be deployed to static hosting platforms such as GitHub Pages, Vercel, Netlify, or AWS Sentry.

---

## 🌐 Deploying to GitHub Pages

Since this is a client-side SPA with static output (`dist/` folder), hosting it on GitHub Pages is free and fast!

I have updated `vite.config.ts` to include `base: './'`. This forces the compiler to use relative asset paths, meaning your built site will run perfectly on sub-directories or standard user domains (e.g., `https://<username>.github.io/<repository-name>/`).

Here is how you can host it:

### Option 1: Automated Deployment using the `gh-pages` Package (Easiest)

1. **Install `gh-pages`** as a dev dependency in your vscode terminal:
   ```bash
   npm install gh-pages --save-dev
   ```

2. **Add Deploy Scripts** inside your `package.json` under `"scripts"`:
   ```json
   "predeploy": "npm run build",
   "deploy": "gh-pages -d dist"
   ```

3. **Deploy with 1 command**:
   ```bash
   npm run deploy
   ```
   This compiles your app to `./dist` and automatically pushes the content to a dedicated `gh-pages` deployment branch on your GitHub repository!

4. **Enable GitHub Pages**:
   * Go to your repository on GitHub.
   * Go to **Settings** > **Pages**.
   * Under **Build and deployment**, ensure your source is set to **Deploy from a branch**, and select **`gh-pages`** as the branch (root folder `/`).

---

## 🎨 Technologies Used

*   **Framework**: [React 18](https://react.dev/) + [Vite](https://vitejs.dev/)
*   **Language**: [TypeScript](https://www.typescriptlang.org/) (for strict type-safety)
*   **Styling**: [Tailwind CSS v4](https://tailwindcss.com/)
*   **Animations**: [Motion](https://motion.dev/)
*   **Icons**: [Lucide React](https://lucide.dev/)
